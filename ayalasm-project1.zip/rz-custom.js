$(document).ready(function(){
	
/* 	INITIAL FADE IN	 */

	$('#wrapper').hide();
	$('#wrapper').fadeIn(2000);
	
	$('#slide1')
		.delay(2500)
		.fadeOut(2000);
	$('#slide2')
		.delay(3000)
		.fadeIn(2000);
	


/* HOVERS */
	$('#acqua').hover(function(){
			$('.acquaBW').fadeOut(300);
			$('.medBW').fadeIn(300);
			$('.terraBW').fadeIn(300);
			$('.soleBW').fadeIn(300);
			$('.auroraBW').fadeIn(300);
			
			
			$('#slide1').fadeOut(1000);
			$('#slide2').fadeOut(1000);
			$('#slide3').fadeIn(1000);
			$('#slide4').fadeOut(1000);
			$('#slide5').fadeOut(1000);
			$('#slide6').fadeOut(1000);
			
	});
	
	$('#med').hover(function(){
			$('.acquaBW').fadeIn(300);
			$('.medBW').fadeOut(300);
			$('.terraBW').fadeIn(300);
			$('.soleBW').fadeIn(300);
			$('.auroraBW').fadeIn(300);
	
			$('#slide1').fadeOut(1000);
			$('#slide2').fadeOut(1000);
			$('#slide3').fadeOut(1000);
			$('#slide4').fadeIn(1000);
			$('#slide5').fadeOut(1000);
			$('#slide6').fadeOut(1000);
	});



	$('#terra').hover(function(){
			$('.acquaBW').fadeIn(300);
			$('.medBW').fadeIn(300);
			$('.terraBW').fadeOut(300);
			$('.soleBW').fadeIn(300);
			$('.auroraBW').fadeIn(300);
			
			$('#slide1').fadeOut(1000);
			$('#slide2').fadeIn(1000);
			$('#slide3').fadeOut(1000);
			$('#slide4').fadeOut(1000);
			$('#slide5').fadeOut(1000);
			$('#slide6').fadeOut(1000);
	});



});