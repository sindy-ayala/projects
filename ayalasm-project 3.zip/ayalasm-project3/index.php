<?php include("includes/a_config.php");?>
<!DOCTYPE html>
<html>
<head>
	<?php include("includes/head-tag-contents.php");?>
</head>
<body>

<?php include("includes/design-top.php");?>
<?php include("includes/navigation.php");?>

<div class="container" id="main-content">
	<h1>How to Get Unstuck</h1><br>
	<h3>Sometimes you’ll beat yourself up and say, “I’m not making progress and I’m not moving forward,” when in fact, you probably are making progress, you’re being hard on yourself.</h3>
<br>
	<p>There will be times in your life when you feel stuck and when you’re stagnant, but when you have those moments, there are three things you should do.

<ol> 
	<li>Analyze when you have been successful in the past</li>
	<li>Be mindful of how you speak to yourself and the language that you’re using</li>
	<li>Begin to identify what you have done right instead of you’ve done wrong</li></ol>
	<p>
		Being an entrepreneur has a lot of ups and downs—maybe even more downs than ups. It’s a roller coaster. I try to remember that every hour presents a new opportunity to keep moving forward rather than dwelling on what happened in the previous hour.
	</p>
</div>

<?php include("includes/footer.php");?>

</body>
</html>