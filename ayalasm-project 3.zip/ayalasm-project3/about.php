<?php include("includes/a_config.php");?>
<!DOCTYPE html>
<html>
<head>
	<?php include("includes/head-tag-contents.php");?>
</head>
<body>

<?php include("includes/design-top.php");?>
<?php include("includes/navigation.php");?>

<div class="container" id="main-content">
	<h1>Importance of Managing Your Energy</h1>
<br>
<h3>One of the most important requirements for being happy and productive is for you to gaurd and nurture your energy levels at all times.</h3><br>
	<p>
		 Starting something of your own means you have to be not only the boss, but the safety net. No one wants it to succeed more than you. There are going to be nights when you get to do really fun things, but more often than not, you are going to have to miss them to clean the bar mats. Having a realistic view of one’s self makes those moments more rewarding and less of a sacrifice knowing there is a bigger goal to achieve.
	</p>
	<p>
		What I realized is, the way I used to work with being crazy efficient with to-do lists and managing my time perfectly, is not getting me to that place where I now want to be.
	</p>
	<p>Energy management is the new time management. Having self-care rituals to manage your personal and professional energy is important to resist burnout, adrenal fatigue and stress overload.</p> 
</div>

<?php include("includes/footer.php");?>

</body>
</html>