<?php include("includes/a_config.php");?>
<!DOCTYPE html>
<html>
<head>
	<?php include("includes/head-tag-contents.php");?>
</head>
<body>

<?php include("includes/design-top.php");?>
<?php include("includes/navigation.php");?>

<div class="container" id="main-content">
	<h1>The Cost of Wasting Time</h1>
	<br>
	<h3>Be brutally honest about how you are spending the most precious resource you have, which is the gift of your time.</h3>
	<br><p>
	The opportunity cost of wasting time is huge, so we have to check ourselves before we wreck ourselves. Everything you say yes to means you’re saying no to something else, so for example, if you say yes to watching Netflix or watching Stranger Things, then you’re saying no to some of your long-term goals. The truth is, you really have to be clear on what you want and be brutally honest about how you are spending the most precious resource you have, which is the gift of your time.
	</p>

</div>

<?php include("includes/footer.php");?>

</body>
</html>